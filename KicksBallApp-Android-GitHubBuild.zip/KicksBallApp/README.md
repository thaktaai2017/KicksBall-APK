# KicksBall Android WebView app

This Android project opens https://kicksball.com/ inside an app WebView.

## Build APK from GitHub Actions (phone-friendly)
1. Create a GitHub repository and upload the contents of this project folder (not the ZIP itself).
2. Make sure `.github/workflows/build-apk.yml` is included.
3. Go to the repository's **Actions** tab and select **Build KicksBall APK**.
4. Tap **Run workflow** (or push to `main`/`master` to start a build).
5. Open the completed run and download the **KicksBall-debug-apk** artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow installing unknown apps for the browser/files app used.

## Notes
- This project is a WebView wrapper; it does not extract or rehost video streams.
- The website's own availability, login, playback, and restrictions remain in effect.
